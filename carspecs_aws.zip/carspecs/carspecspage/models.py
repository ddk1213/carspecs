from carspecspage import db

class Manufacture(db.Model):
    manufacture = db.Column(db.String(20), primary_key=True)


class CarList(db.Model):
    modelName = db.Column(db.String(20), primary_key=True)
    manufacture = db.Column(db.String(20))


class CarListDetail(db.Model):
    detailModelName = db.Column(db.String(100), primary_key=True)
    length = db.Column(db.Integer)
    width = db.Column(db.Integer)
    height = db.Column(db.Integer)
    modelName = db.Column(db.String(20))